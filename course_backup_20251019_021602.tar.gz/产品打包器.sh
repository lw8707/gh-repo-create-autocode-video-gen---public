#!/bin/bash
echo "📦 启动产品打包流程..."

# 创建产品目录结构
mkdir -p 产品化版本/脚本
mkdir -p 产品化版本/课程
mkdir -p 产品化版本/文档

# 复制核心文件
cp *.sh 产品化版本/脚本/
cp *.json 产品化版本/
cp *.md 产品化版本/文档/

echo "✅ 产品目录结构创建完成"
echo "📱 下一步: 研究Termux APK打包工具"
