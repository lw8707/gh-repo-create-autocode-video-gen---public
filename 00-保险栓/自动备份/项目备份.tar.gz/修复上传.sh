#!/bin/bash
echo "🔧 修复自动上传功能"
git add .
git commit -m "修复: $(date '+%Y-%m-%d %H:%M:%S')"
git push origin main
echo "✅ 手动上传完成"
