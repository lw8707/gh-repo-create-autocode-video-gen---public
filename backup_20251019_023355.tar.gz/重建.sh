#!/bin/bash
echo "=== 第21轮重建开始 ==="
pwd
ls -la
echo "✅ 重建完成"
