#!/bin/bash
cd ~/my-ai-business/我的智能体课程
nohup python 智能自检修复系统.py > 监控日志.txt 2>&1 &
echo "🔄 智能监控系统已在后台启动"
echo "📝 查看日志: tail -f 监控日志.txt"
